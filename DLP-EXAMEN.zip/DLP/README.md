# 💻​ DLP - Compilador TypeScript
Este es mi proyecto para la asignatura DLP del Grado en Ingeniería del Software de la Universidad de Oviedo. Aquí iré subiendo lo que vaya haciendo a lo largo de las distintas sesiones prácticas de la asignatura.

Mi compilador en concreto incluye las prácticas desarrolladas con Óscar, que en **2025** fueron sobre **TypeScript**. El modelo cambia dependiendo del profesor (y puede que del año), aunque no varía en exceso.
