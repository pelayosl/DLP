package symboltable;

import java.util.*;
import ast.locatables.Definition;

public class SymbolTable {
	
	private int scope=0;
	private final List<Map<String, Definition>> table;
	public SymbolTable()  {
		this.table = new ArrayList<Map<String, Definition>>();
		table.add(new HashMap<String, Definition>()); // Global scope
	}

	public void set() {
		scope++;
		table.add(new HashMap<String, Definition>()); // Local scope
	}
	
	public void reset() {
		table.remove(scope);
		scope--;
	}
	
	public boolean insert(Definition definition) {
		if(!findInCurrentScope(definition.getName())) {
			table.get(scope).put(definition.getName(), definition);
			definition.setScope(scope);
			return true;
		}
		return false;
	}
	
	public Definition find(String id) {
		for(int i=scope; i>=0; i--) {
			Definition definition = table.get(i).get(id);
			if(definition!=null) return definition;
		}
		return null;
	}
	//package-protected for testing pourposes
	boolean findInCurrentScope(String id) {
        return table.get(scope).get(id) != null;
    }
}
