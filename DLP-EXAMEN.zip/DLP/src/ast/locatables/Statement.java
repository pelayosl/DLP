package ast.locatables;

import ast.Locatable;

public interface Statement extends Locatable {
}
